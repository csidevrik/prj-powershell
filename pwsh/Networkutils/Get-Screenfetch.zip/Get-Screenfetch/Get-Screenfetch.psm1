# Get-Screenfetch.psm1
Get-ChildItem -Path "$PSScriptRoot\Public\*.ps1" | ForEach-Object { . $_ }